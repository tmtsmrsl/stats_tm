# stats_tm package

This package can visualize binomial, poisson, normal and student's T distributions; and calculate their probability mass or density function along with their cumulative probability.